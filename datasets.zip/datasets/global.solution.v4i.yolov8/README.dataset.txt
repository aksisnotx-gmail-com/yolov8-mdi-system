# global solution > 2024-06-02 10:25am
https://universe.roboflow.com/reconhecimentoimgs/global-solution

Provided by a Roboflow user
License: CC BY 4.0

